# Mr RB Predictions

Free Android football prediction app using local historical match data, Elo and Poisson-style goal modelling.

## Included market engine
- Full-time 1X2, double chance, DNB
- Full-match over/under 0.5 through 10.5+
- 1-5, 1-10 and 1-15 goal ranges
- Multigoals and exact goals
- Home/away team goals
- BTTS and clean sheets
- 1st-half and 2nd-half 1X2, double chance, DNB and over/under
- 1st/2nd-half BTTS and team-goal markets
- Both-halves markets
- Half-time/full-time combinations
- Highest-scoring-half
- Correct score
- Goal handicaps
- Combination result + goals/BTTS markets
- Corners and bookings when the imported data contains those statistics

Player-specific, minute-band and live/in-play markets require event-level/live/player data and are never fabricated by the model.

## Data
The app supports Football-Data CSV results and openfootball public-domain result datasets where available.


## Mr RB Predictions V3 upgrade
- Optional API-Football integration for fixtures, pre-match/live odds, standings, historical seasons, injuries and lineups.
- API key is entered at runtime and stored locally on the device.
- Model markets show probability, confidence score and fair odds.
- Market selector automatically analyses the selected supported market after a match is analysed.
- The app does not invent unsupported live/player/minute markets.


## V4 additions
- Prediction history with final-result grading for supported markets.
- In-app messages and Android notifications.
- Saved probability, confidence, fair odds and returned bookmaker odds.
- Value calculation when a matching bookmaker price is available.
- Live fixture selections can be saved as analyses and checked later.
- Current and previous-season standings via API-Football.

Important: live API data requires a valid API-Football key. The app never fabricates missing odds or unsupported market results. Android notifications require the user to grant notification permission.
