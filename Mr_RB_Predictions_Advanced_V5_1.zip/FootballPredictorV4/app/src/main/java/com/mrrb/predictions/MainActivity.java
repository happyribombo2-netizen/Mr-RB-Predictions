package com.mrrb.predictions;

import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView web;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setTextZoom(100);

        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new NetBridge(), "AndroidNet");
        web.addJavascriptInterface(new NotifyBridge(), "AndroidNotify");
        createNotificationChannel();
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);
    }

    public class NetBridge {
        @JavascriptInterface
        public void getHttps(final String url, final String callbackId) {
            download(url, callbackId);
        }

        // Backward-compatible alias for older builds.
        @JavascriptInterface
        public void get(final String url, final String callbackId) {
            download(url, callbackId, null);
        }

        @JavascriptInterface
        public void apiGet(final String url, final String apiKey, final String callbackId) {
            download(url, callbackId, apiKey);
        }

        private void download(final String url, final String callbackId, final String apiKey) {
            if (!isAllowedUrl(url)) {
                sendResult(callbackId, false, "Blocked URL. Only approved HTTPS football data sources are allowed.", apiKey != null);
                return;
            }

            new Thread(() -> {
                boolean ok = false;
                String result;

                HttpURLConnection connection = null;
                try {
                    URL target = new URL(url);
                    connection = (HttpURLConnection) target.openConnection();
                    connection.setInstanceFollowRedirects(true);
                    connection.setConnectTimeout(20000);
                    connection.setReadTimeout(45000);
                    connection.setUseCaches(false);
                    connection.setRequestProperty("User-Agent", "Mr-RB-Predictions/3.0");
                    connection.setRequestProperty("Accept", "application/json,text/plain,text/csv,text/*,*/*;q=0.8");
                    if (apiKey != null && !apiKey.trim().isEmpty()) {
                        connection.setRequestProperty("x-apisports-key", apiKey.trim());
                    }

                    int code = connection.getResponseCode();
                    InputStream stream = (code >= 200 && code < 400)
                            ? connection.getInputStream()
                            : connection.getErrorStream();

                    if (stream == null) {
                        result = "HTTP " + code;
                    } else {
                        ByteArrayOutputStream out = new ByteArrayOutputStream();
                        byte[] buffer = new byte[8192];
                        int read;
                        while ((read = stream.read(buffer)) != -1) {
                            out.write(buffer, 0, read);
                            if (out.size() > 8 * 1024 * 1024) {
                                throw new Exception("Download is larger than 8 MB.");
                            }
                        }
                        stream.close();
                        result = new String(out.toByteArray(), "UTF-8");
                        ok = code >= 200 && code < 300;
                        if (!ok && result.length() == 0) {
                            result = "HTTP " + code;
                        }
                    }
                } catch (Exception e) {
                    String message = e.getMessage();
                    result = e.getClass().getSimpleName() + (message == null ? "" : ": " + message);
                } finally {
                    if (connection != null) {
                        connection.disconnect();
                    }
                }

                sendResult(callbackId, ok, result, apiKey != null);
            }).start();
        }

        private boolean isAllowedUrl(String url) {
            if (url == null) return false;
            try {
                URL u = new URL(url);
                if (!"https".equalsIgnoreCase(u.getProtocol())) return false;

                String host = u.getHost().toLowerCase(Locale.US);
                String path = u.getPath();

                if ("www.football-data.co.uk".equals(host) || "football-data.co.uk".equals(host)) {
                    return true;
                }

                if ("raw.githubusercontent.com".equals(host)) {
                    return path.startsWith("/openfootball/world/");
                }

                return "api-football.com".equals(host)
                        || "v3.football.api-sports.io".equals(host)
                        || "v3.football.api-sports.io".equals(host);
            } catch (Exception e) {
                return false;
            }
        }

        private void sendResult(final String callbackId, final boolean ok, final String data, final boolean api) {
            final String safeId = callbackId == null ? "" : callbackId.replaceAll("[^A-Za-z0-9_-]", "");
            final String escaped = escapeJs(data == null ? "" : data);

            mainHandler.post(() -> {
                if (web == null) return;
                String script = (api ? "window.renderApiDone(" : "window.__nativeDownloadDone(") + "'" + safeId + "'," + ok + ",\"" + escaped + "\")";
                web.evaluateJavascript(script, null);
            });
        }

        private String escapeJs(String value) {
            return value.replace("\\", "\\\\")
                    .replace("\"", "\\\"")
                    .replace("\r", "\\r")
                    .replace("\n", "\\n")
                    .replace("\u2028", "\\u2028")
                    .replace("\u2029", "\\u2029");
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel("mrrb_updates", "Mr RB Predictions", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Mr RB Predictions match and result updates");
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    public class NotifyBridge {
        @JavascriptInterface
        public void request() {
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 77);
            }
        }

        @JavascriptInterface
        public void show(final String title, final String body) {
            mainHandler.post(() -> {
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;
                NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                if (nm == null) return;
                android.app.Notification.Builder b;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) b = new android.app.Notification.Builder(MainActivity.this, "mrrb_updates");
                else b = new android.app.Notification.Builder(MainActivity.this);
                b.setSmallIcon(com.mrrb.predictions.R.drawable.ic_launcher)
                 .setContentTitle(title == null ? "Mr RB Predictions" : title)
                 .setContentText(body == null ? "New update" : body)
                 .setAutoCancel(true);
                nm.notify((int)(System.currentTimeMillis() & 0x7fffffff), b.build());
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
