# Mr RB Predictions V8.0

This Android WebView project keeps the V7.5 prediction/model/market logic and adds a redesigned football-app-style interface.

Build with Java 17 and Gradle 8.7 / Android Gradle Plugin 8.5.2.
