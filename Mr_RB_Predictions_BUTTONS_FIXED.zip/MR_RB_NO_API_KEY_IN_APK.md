The APK does not contain a user-facing provider API-key entry field.
Provider credentials belong on the Mr RB Sports API server.
The APK calls the Mr RB server and the server calls configured data providers.
Set MR_RB_API_BASE at build/deployment time; do not ask the user to enter provider keys.
