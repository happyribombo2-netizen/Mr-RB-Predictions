# Provider architecture for global sports

No single provider reliably supplies every sport and every betting market worldwide. Mr RB therefore uses a provider-adapter architecture.

Android:
  APK -> Mr RB Sports API -> provider adapters -> cache/database -> normalized events/statistics/odds -> prediction engine

Rules:
1. Never put provider secrets in the APK.
2. Never fabricate a market when the feed lacks the necessary fields.
3. Preserve the full sport/market catalogue even when a provider is temporarily unavailable.
4. For Tennis/Golf and other sports not supported by the current API-Sports product list, configure a licensed specialist provider adapter.
5. Competition availability is checked by sport, country, gender, age group and season.
6. Live micro-markets require event-level live feeds; pre-match historical data alone is insufficient.
