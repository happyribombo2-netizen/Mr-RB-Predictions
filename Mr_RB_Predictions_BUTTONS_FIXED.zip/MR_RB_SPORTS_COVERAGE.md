# Mr RB Predictions V9.1 — sports and competition coverage

## Sports included
Mr RB is structured for every sport currently exposed by the API-Sports product family used by this project:
Football, Basketball, Baseball, Formula 1, Handball, Hockey, Rugby, Volleyball, NFL/American Football, NBA, AFL and MMA.

## Competition scopes
The APK must expose:
- All competitions
- National teams / country representation
- International / continental / world competitions
- Domestic club competitions
- Women's competitions
- Youth competitions
- Search across teams, leagues and competitions

National games are **not a separate sport**. They are competitions/events within a sport, such as national-team friendlies, World Cup qualification, continental championships, Nations competitions, Olympics and youth national tournaments where the provider supplies them.

## No intentional hard-coded exclusion
Featured competitions are only shortcuts. The `Discover all competitions` path calls the Mr RB server's `/catalog/:sport` endpoint so the APK can browse the provider's current competition catalogue rather than being limited to a hard-coded list.

## Data integrity
The app must never invent a fixture, score, player statistic, market settlement, odds value or coverage capability. If a sport/competition does not supply a particular statistic or market, that market is shown as unavailable rather than fabricated.

## Football preservation
All existing football prediction and market functionality is retained. This multi-sport expansion is additive.
