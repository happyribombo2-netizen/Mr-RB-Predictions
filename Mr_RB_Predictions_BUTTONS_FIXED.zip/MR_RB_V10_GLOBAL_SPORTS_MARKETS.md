# Mr RB Predictions V10 — Global Sports + Market Registry

This build keeps the existing V9.1 application and expands the local sport/market catalogue.

## Added
- Tennis
- Golf
- Cricket
- Boxing
- Darts
- Snooker
- Table tennis
- Badminton
- Beach volleyball
- Futsal
- Esports
- Horse racing
- Greyhounds
- Cycling
- Athletics
- Swimming
- Gymnastics
- Diving
- Rowing
- Wrestling
- Water polo
- Lacrosse
- Netball
- Motorsport
- Motorbikes
- Equestrian
- Speedway
- Winter sports / skiing
- Surfing
- Skateboarding
- Sport climbing
- Squash
- Padel
- Pickleball
- Pool / table sports
- Ten-pin bowling
- Kabaddi
- Gaelic sports
- Sepak takraw
- Pelota
- Pesapallo
- Sailing
- Triathlon
- Weightlifting
- Sumo
- Shooting
- Fencing
- Modern pentathlon
- Floorball
- Softball
- Drone racing
- Virtual sports

The existing sports remain.

## Market approach
The registry contains sport-specific markets plus reusable market families (winner, handicap/spread, totals, team/player props, segment markets, outrights, etc.). The app must only calculate a market when the underlying provider data supports it. It must not invent player, live, card, corner, pitch, micro-bet or other event data.

## Coverage
The app supports national, international, domestic, women and youth discovery scopes. Actual competitions are provider-dependent and are discovered at runtime.

## No provider key in APK
Provider secrets remain server-side. The Android app does not contain provider API keys. A deployed Mr RB Sports API is required for live provider data.

## Important
This is a source/build upgrade, not proof that every sport or every market is available from one data provider. Some sports require multiple providers. The backend must be configured with licensed data sources for the markets actually exposed.
