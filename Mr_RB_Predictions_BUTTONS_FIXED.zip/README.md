# Mr RB Predictions V8.0 — Premium-style personal football analytics

V8 keeps the V7.5 prediction engine and all existing market functions, while rebuilding the navigation around a clear football match-centre layout.

## What changed
- Separate **Live**, **Upcoming**, and **Finished** match views.
- Global **team / fixture / league search** at the top.
- Dedicated **Leagues** browser with favourites and league fixtures.
- Dedicated **Prediction Desk** so analysing a match does not require scrolling to API settings.
- Dedicated **Data/API** settings screen.
- Mobile bottom navigation for Home, Matches, Leagues, Predict and Markets.
- Cleaner match cards, league grouping, status labels, and date/search filters.
- Upcoming predictor picker remains grouped by league and country.
- Existing prediction engine and market catalogue are retained; no original JavaScript functions were removed from V7.5.
- Provider-dependent markets are only calculated when reliable provider data exists.

## Important API limitation
The app does not impose an artificial league limit, and the provider integration uses pagination where practical. However, no external football API can honestly be made unlimited for free: API-Football plans have request quotas and coverage varies by competition. V8 is structured so additional providers/backends can be added later without redesigning the prediction UI.

## Verification
- JavaScript syntax checked with Node.
- Compared against V7.5: 103/103 original JavaScript functions remain present; V8 adds navigation/search/match-centre functions.
- Physical Android tapping and provider-account behaviour still need to be tested on the user's phone.


## V10 global sports market expansion
See `MR_RB_V10_GLOBAL_SPORTS_MARKETS.md` and `MR_RB_PROVIDER_ARCHITECTURE.md`.

## GitHub Actions APK build

The repository includes `.github/workflows/build-apk.yml`. In GitHub:
1. Open **Actions**.
2. Select **Build Mr RB Predictions APK**.
3. Tap **Run workflow**.
4. After it finishes, open the workflow run and download **Mr-RB-Predictions-V10-debug-apk** from Artifacts.

The workflow uses Java 17 and Gradle 8.7, verifies the Android project before building, supports either the checked-in Gradle wrapper or the runner's Gradle 8.7 installation, and fails clearly if an APK is not produced.
