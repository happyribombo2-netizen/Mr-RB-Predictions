# Mr RB Personal API

This is the personal API layer for Mr RB Predictions. It is included with the project and is not an API-Sports proxy.

## Request limits
There is **no artificial request-per-minute limit and no daily request quota in this code**. Capacity is limited only by the server hardware, network and any upstream source used by a collector.

## Important data rule
The API does not fabricate real-world fixtures, scores, player events or odds. Put licensed/provider data into the local store through the ingest endpoints or build provider adapters that write to the same store. Once stored, the APK can read the data repeatedly without making a provider request for every read.

## Run
```
npm install
npm start
```

Default: `http://localhost:8080`

## Main endpoints
- `/health`
- `/v1/sports`
- `/v1/sports/:sport`
- `/v1/sports/:sport/markets`
- `/v1/catalog`
- `/v1/events`
- `/v1/competitions`
- `/v1/results`
- `/v1/stats`
- `/v1/news`
- `/v1/predictions`
- `/v1/snapshot`
- `POST /v1/ingest/:resource`
- `POST /v1/predictions`

The Android project is intentionally not modified by this API-only update.
