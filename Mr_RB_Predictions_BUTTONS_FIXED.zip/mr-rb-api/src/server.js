import Fastify from 'fastify';
import cors from '@fastify/cors';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DATA_DIR = path.resolve(__dirname, '..', 'data');
const app = Fastify({ logger: true, bodyLimit: 50 * 1024 * 1024 });
await app.register(cors, { origin: true });

// Personal API: deliberately NO Fastify rate-limit plugin and NO daily request quota.
// Capacity is determined by the machine/network hosting this server, not a software quota.
const files = {
  sports: 'sports.json',
  events: 'events.json',
  competitions: 'competitions.json',
  results: 'results.json',
  stats: 'stats.json',
  news: 'news.json',
  predictions: 'predictions.json'
};

async function read(name) {
  return JSON.parse(await fs.readFile(path.join(DATA_DIR, files[name]), 'utf8'));
}
async function write(name, value) {
  const target = path.join(DATA_DIR, files[name]);
  const tmp = `${target}.tmp`;
  await fs.writeFile(tmp, JSON.stringify(value, null, 2));
  await fs.rename(tmp, target);
}
function matchesFilters(row, query) {
  return Object.entries(query).every(([key, value]) => {
    if (value == null || value === '') return true;
    const actual = row?.[key];
    if (Array.isArray(actual)) return actual.map(String).includes(String(value));
    return String(actual ?? '').toLowerCase() === String(value).toLowerCase();
  });
}

app.get('/health', async () => ({
  ok: true,
  service: 'Mr RB Personal Sports API',
  version: '1.0.0',
  request_limit: null,
  daily_quota: null,
  artificial_rate_limit: false,
  storage: 'local persistent JSON',
  note: 'No software request quota is imposed by this API.'
}));

app.get('/v1/health', async (req, reply) => reply.send(await app.inject({ method: 'GET', url: '/health' }).then(r => JSON.parse(r.body))));

app.get('/sports', async () => {
  const data = await read('sports');
  return Object.values(data).map(s => ({ id: s.id, market_count: s.markets.length }));
});
app.get('/v1/sports', async () => app.inject({ method: 'GET', url: '/sports' }).then(r => JSON.parse(r.body)));

app.get('/sports/:sport', async (req, reply) => {
  const data = await read('sports');
  const sport = data[req.params.sport];
  if (!sport) return reply.code(404).send({ error: 'Sport not found' });
  return sport;
});
app.get('/v1/sports/:sport', async (req, reply) => app.inject({ method: 'GET', url: `/sports/${encodeURIComponent(req.params.sport)}` }).then(r => { reply.code(r.statusCode); return JSON.parse(r.body); }));

app.get('/sports/:sport/markets', async (req, reply) => {
  const data = await read('sports');
  const sport = data[req.params.sport];
  if (!sport) return reply.code(404).send({ error: 'Sport not found' });
  return { sport: sport.id, markets: sport.markets, count: sport.markets.length };
});
app.get('/v1/sports/:sport/markets', async (req, reply) => app.inject({ method: 'GET', url: `/sports/${encodeURIComponent(req.params.sport)}/markets` }).then(r => { reply.code(r.statusCode); return JSON.parse(r.body); }));

for (const resource of ['events','competitions','results','stats','news','predictions']) {
  app.get(`/${resource}`, async req => {
    const rows = await read(resource);
    return { data: rows.filter(row => matchesFilters(row, req.query || {})), count: rows.length };
  });
  app.get(`/v1/${resource}`, async req => app.inject({ method: 'GET', url: `/${resource}${req.raw.url.includes('?') ? req.raw.url.slice(req.raw.url.indexOf('?')) : ''}` }).then(r => JSON.parse(r.body)));
}

app.get('/events/:id', async (req, reply) => {
  const rows = await read('events');
  const row = rows.find(x => String(x.id) === String(req.params.id));
  if (!row) return reply.code(404).send({ error: 'Event not found' });
  return row;
});

// Bulk ingestion endpoint for your own collectors/provider adapters.
// It stores data locally so repeated APK reads do not consume an upstream request.
app.post('/v1/ingest/:resource', async (req, reply) => {
  const resource = req.params.resource;
  if (!files[resource] || resource === 'sports') return reply.code(400).send({ error: 'Invalid ingest resource' });
  const incoming = Array.isArray(req.body) ? req.body : (Array.isArray(req.body?.data) ? req.body.data : null);
  if (!incoming) return reply.code(400).send({ error: 'Body must be an array or {data:[...]}' });
  await write(resource, incoming);
  return { ok: true, resource, stored: incoming.length, request_limit: null };
});

app.post('/v1/predictions', async (req, reply) => {
  const existing = await read('predictions');
  const item = { id: req.body?.id ?? `prediction-${Date.now()}`, created_at: new Date().toISOString(), ...req.body };
  existing.push(item);
  await write('predictions', existing);
  return reply.code(201).send(item);
});

app.get('/v1/catalog', async () => {
  const data = await read('sports');
  return { sports: Object.values(data), total_sports: Object.keys(data).length };
});

app.get('/v1/snapshot', async () => {
  const [events, competitions, results, stats, news, predictions] = await Promise.all([
    read('events'), read('competitions'), read('results'), read('stats'), read('news'), read('predictions')
  ]);
  return { counts: { events: events.length, competitions: competitions.length, results: results.length, stats: stats.length, news: news.length, predictions: predictions.length }, updated_at: new Date().toISOString() };
});

const port = Number(process.env.PORT || 8080);
const host = process.env.HOST || '0.0.0.0';
await app.listen({ host, port });
