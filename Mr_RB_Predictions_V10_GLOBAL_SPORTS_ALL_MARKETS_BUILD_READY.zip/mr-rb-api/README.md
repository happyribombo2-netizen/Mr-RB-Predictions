# Mr RB Sports API

Backend for Mr RB Predictions. Provider credentials stay server-side; the Android APK does not need users to enter provider API keys.

## Supported API-Sports products
Football, Basketball, Baseball, Hockey, Handball, Rugby, Volleyball, NFL/American Football, NBA, AFL, MMA and Formula 1.

Set provider keys as server environment variables. The API caches repeated reads so a large number of APK requests does not become the same number of upstream provider calls.

This backend does not bypass provider quotas. It is designed to scale the **Mr RB API** through caching and controlled upstream synchronization.
