import Fastify from 'fastify';
import cors from '@fastify/cors';
import rateLimit from '@fastify/rate-limit';
import { LRUCache } from 'lru-cache';

const app=Fastify({logger:true});
await app.register(cors,{origin:true});
await app.register(rateLimit,{max:3000,timeWindow:'1 minute'});
const cache=new LRUCache({max:5000,ttl:30000});
const providers={
  football:{base:'https://v3.football.api-sports.io',key:process.env.API_FOOTBALL_KEY},
  basketball:{base:'https://v1.basketball.api-sports.io',key:process.env.API_BASKETBALL_KEY},
  baseball:{base:'https://v1.baseball.api-sports.io',key:process.env.API_BASEBALL_KEY},
  hockey:{base:'https://v1.hockey.api-sports.io',key:process.env.API_HOCKEY_KEY},
  handball:{base:'https://v1.handball.api-sports.io',key:process.env.API_HANDBALL_KEY},
  rugby:{base:'https://v1.rugby.api-sports.io',key:process.env.API_RUGBY_KEY},
  volleyball:{base:'https://v1.volleyball.api-sports.io',key:process.env.API_VOLLEYBALL_KEY},
  nfl:{base:'https://v1.american-football.api-sports.io',key:process.env.API_NFL_KEY},
  nba:{base:'https://v2.nba.api-sports.io',key:process.env.API_NBA_KEY},
  afl:{base:'https://v1.afl.api-sports.io',key:process.env.API_AFL_KEY},
  mma:{base:'https://v1.mma.api-sports.io',key:process.env.API_MMA_KEY},
  formula1:{base:'https://v1.formula-1.api-sports.io',key:process.env.API_F1_KEY}
};
app.get('/health',async()=>({ok:true,service:'Mr RB Sports API',cache:'enabled',version:'2.0.0',catalog:'global-sports-v10'}));
app.get('/sports',async()=>Object.keys(providers).map(id=>({id,configured:Boolean(providers[id].key)})));
app.get('/catalog/:sport',async(req,reply)=>{
  const sport=req.params.sport; const p=providers[sport];
  if(!p)return reply.code(404).send({error:'Unsupported sport'});
  if(!p.key)return reply.code(503).send({error:'Provider key not configured on Mr RB server'});
  const key='catalog:'+sport; const cached=cache.get(key); if(cached)return cached;
  const endpoint=sport==='football'?'/leagues':'/leagues';
  const r=await fetch(p.base+endpoint,{headers:{'x-apisports-key':p.key,'accept':'application/json'}});
  const text=await r.text(); if(!r.ok)return reply.code(r.status).send(text);
  let body; try{body=JSON.parse(text)}catch{body={raw:text}}; cache.set(key,body); return body;
});

// Global catalogue endpoint. It describes supported adapters without exposing secrets.
const globalSports = [
  "football","basketball","baseball","hockey","handball","rugby","volleyball","nfl","nba","afl","mma","formula1",
  "tennis","golf","cricket","boxing","darts","snooker","table-tennis","badminton","beach-volleyball","futsal",
  "esports","horse-racing","greyhounds","cycling","athletics","swimming","gymnastics","diving","rowing","wrestling",
  "water-polo","lacrosse","netball","motorsport","motorbikes","equestrian","speedway","winter-sports","skiing",
  "surfing","skateboarding","sport-climbing","squash","padel","pickleball","pool","bowling","kabaddi","gaelic",
  "sepak-takraw","pelota","pesapallo","sailing","triathlon","weightlifting","sumo","shooting","fencing",
  "modern-pentathlon","floorball","softball","drone-racing","virtual-sports"
];
app.get('/global-sports',async()=>globalSports.map(id=>({id,configured:Boolean(providers[id]?.key),adapter:providers[id]?'api-sports':'external-provider-required'})));

app.get('/proxy/:sport/*',async(req,reply)=>{
  const sport=req.params.sport; const p=providers[sport];
  if(!p)return reply.code(404).send({error:'Unsupported sport'});
  if(!p.key)return reply.code(503).send({error:'Provider key not configured on Mr RB server'});
  const tail=req.params['*']||''; const qs=new URLSearchParams(req.query||{}).toString();
  const url=p.base+'/'+tail+(qs?'?'+qs:''); const key='proxy:'+url; const cached=cache.get(key); if(cached)return cached;
  const r=await fetch(url,{headers:{'x-apisports-key':p.key,'accept':'application/json'}}); const text=await r.text();
  if(!r.ok)return reply.code(r.status).send(text);
  let body; try{body=JSON.parse(text)}catch{body={raw:text}}; cache.set(key,body); return body;
});
app.listen({host:'0.0.0.0',port:Number(process.env.PORT||8080)});
