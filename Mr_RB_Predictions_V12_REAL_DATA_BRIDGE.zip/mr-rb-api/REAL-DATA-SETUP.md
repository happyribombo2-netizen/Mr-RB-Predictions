# Mr RB real football data bridge

This package keeps the existing Android project untouched and adds a server-side provider bridge.

## Data flow
Android APK -> Mr RB Personal API -> API-Football -> Mr RB normalized cache -> APK

## Server secret
Set `API_FOOTBALL_KEY` in the server environment. It is intentionally NOT included in the APK.

## Automatic operation
When the key is configured, the server automatically:
- syncs upcoming football fixtures and current leagues every `FOOTBALL_SYNC_MINUTES` (default 5)
- refreshes live football fixtures at least every minute
- stores normalized data in `data/events.json` and `data/competitions.json`

The APK reads Mr RB endpoints; users do not enter provider credentials.

## Important
"No limits" refers to this Mr RB API not imposing a daily request quota. The upstream provider's plan, contract, coverage and licensing still apply.
