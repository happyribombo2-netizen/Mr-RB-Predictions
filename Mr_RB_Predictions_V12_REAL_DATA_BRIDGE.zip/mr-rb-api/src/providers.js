import fs from 'node:fs/promises';
import path from 'node:path';

const DATA_DIR = path.resolve(process.cwd(), 'data');

async function saveJson(file, value) {
  const target = path.join(DATA_DIR, file);
  const tmp = `${target}.tmp`;
  await fs.writeFile(tmp, JSON.stringify(value, null, 2));
  await fs.rename(tmp, target);
}

function iso(v) {
  return v ? new Date(v).toISOString() : null;
}

function normalizeFixture(x) {
  return {
    id: `apifootball-${x.fixture?.id ?? x.id}`,
    provider: 'api-football',
    provider_id: x.fixture?.id ?? x.id,
    sport: 'football',
    status: x.fixture?.status?.short ?? x.status?.short ?? 'NS',
    status_long: x.fixture?.status?.long ?? x.status?.long ?? null,
    kickoff: iso(x.fixture?.date ?? x.date),
    venue: x.fixture?.venue ?? null,
    league: x.league ?? null,
    home: x.teams?.home ?? null,
    away: x.teams?.away ?? null,
    goals: x.goals ?? null,
    score: x.score ?? null,
    raw: x
  };
}

function normalizeLeague(x) {
  return {
    id: `apifootball-league-${x.league?.id ?? x.id}`,
    provider: 'api-football',
    provider_id: x.league?.id ?? x.id,
    sport: 'football',
    name: x.league?.name ?? x.name,
    country: x.country ?? null,
    logo: x.league?.logo ?? x.logo ?? null,
    seasons: x.seasons ?? []
  };
}

async function apiFootball(pathname, params = {}) {
  const key = process.env.API_FOOTBALL_KEY || process.env.API_SPORTS_KEY;
  if (!key) throw new Error('API_FOOTBALL_KEY is not configured on the server');
  const base = process.env.API_FOOTBALL_BASE || 'https://v3.football.api-sports.io';
  const url = new URL(pathname, base);
  for (const [k, v] of Object.entries(params)) if (v !== undefined && v !== null && v !== '') url.searchParams.set(k, v);
  const res = await fetch(url, { headers: { 'x-apisports-key': key } });
  if (!res.ok) throw new Error(`API-Football HTTP ${res.status}`);
  const json = await res.json();
  if (json.errors && Object.keys(json.errors).length) throw new Error(JSON.stringify(json.errors));
  return json.response ?? [];
}

export async function providerStatus() {
  return {
    api_football: {
      configured: Boolean(process.env.API_FOOTBALL_KEY),
      base: process.env.API_FOOTBALL_BASE || 'https://v3.football.api-sports.io'
    }
  };
}

export async function syncFootball({ from, to } = {}) {
  if (!process.env.API_FOOTBALL_KEY) {
    return { ok: false, provider: 'api-football', skipped: true, reason: 'API_FOOTBALL_KEY is not configured on the server' };
  }
  const today = new Date();
  const start = from || today.toISOString().slice(0, 10);
  const end = to || new Date(today.getTime() + 7 * 86400000).toISOString().slice(0, 10);
  const [fixtures, leagues] = await Promise.all([
    apiFootball('/fixtures', { from: start, to: end }),
    apiFootball('/leagues', { current: 'true' })
  ]);
  const normalizedFixtures = fixtures.map(normalizeFixture);
  const normalizedLeagues = leagues.map(normalizeLeague);
  await Promise.all([
    saveJson('events.json', normalizedFixtures),
    saveJson('competitions.json', normalizedLeagues)
  ]);
  return { ok: true, provider: 'api-football', events: normalizedFixtures.length, competitions: normalizedLeagues.length, from: start, to: end, synced_at: new Date().toISOString() };
}

export async function syncFootballLive() {
  if (!process.env.API_FOOTBALL_KEY) return { ok: false, skipped: true, reason: 'API_FOOTBALL_KEY is not configured on the server' };
  const fixtures = await apiFootball('/fixtures', { live: 'all' });
  const normalized = fixtures.map(normalizeFixture);
  const current = JSON.parse(await fs.readFile(path.join(DATA_DIR, 'events.json'), 'utf8'));
  const map = new Map(current.map(x => [String(x.provider_id ?? x.id), x]));
  for (const item of normalized) map.set(String(item.provider_id), item);
  await saveJson('events.json', [...map.values()]);
  return { ok: true, provider: 'api-football', live_events: normalized.length, synced_at: new Date().toISOString() };
}
