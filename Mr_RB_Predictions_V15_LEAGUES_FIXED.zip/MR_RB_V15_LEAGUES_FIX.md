# V15 league loading fix

The Leagues > Load path now falls back to the built-in league catalogue when the live Mr RB server/provider is unavailable. Existing live-provider behaviour is retained when the server is configured. No sports, markets, prediction logic, or existing UI features were removed.
