# Mr RB Predictions — Organized Infrastructure (V15)

This layer separates the system by responsibility. Legacy `mr-rb-api/` remains for compatibility; nothing is removed.

- api/: API contract and service boundary
- database/: schemas, migrations and storage policy
- prediction-engine/: Poisson, Elo, form, probability and confidence logic
- hosting/: deployment/container infrastructure
- monitoring/: health checks, metrics, logs and alerts
- security/: secrets, authentication and API protection
- admin/: league/model/API/user administration

The Android APK remains the client. Real-world live data still requires a reachable provider-backed Mr RB server; this source package does not invent that infrastructure or fabricate data.
