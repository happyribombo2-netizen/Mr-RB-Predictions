# Database
Separate storage responsibility for current data, historical data, results, predictions and analytics.
