# Prediction Engine
Poisson + Elo + Form + probability/confidence calculation and market evaluation.
