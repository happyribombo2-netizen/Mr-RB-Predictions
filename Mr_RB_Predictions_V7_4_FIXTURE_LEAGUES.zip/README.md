# Mr RB Predictions V5 — Final Build Package

Android project for `com.mrrb.predictions`.

## Build
The GitHub Actions workflow is at `.github/workflows/build-apk.yml` and builds `FootballPredictorV4/app` with Java 17 and Gradle 8.7.

## Included prediction markets
The current app includes full-time 1X2, double chance, DNB, goal totals from 0.5 through 10.5, goal ranges including 1–5, 1–10 and 1–15 goals, BTTS, team totals, first-half and second-half markets, both-halves markets, HT/FT, highest-scoring half, correct score, handicaps, result + totals, result + BTTS, odd/even, clean-sheet/team-to-score estimates, plus corners/cards where source data is available.

Minute-band, player-specific and live event markets are only calculated when reliable event/player data is available; the app does not fabricate those probabilities.


V7.4 UI update: Predictor now uses an upcoming-fixture picker grouped by league and loads the full returned fixture set for the next 7 days. Historical form is displayed after selecting a fixture. Markets catalog is visible before analysis.
